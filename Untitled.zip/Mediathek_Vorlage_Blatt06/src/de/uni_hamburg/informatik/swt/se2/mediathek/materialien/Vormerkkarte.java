package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

public class Vormerkkarte
{
	private Kunde _entleiher;
    private Kunde _vormerker1;
    private Kunde _vormerker2;
    private Kunde _vormerker3;
    
//    public Vormerkkarte()
//    {
//    	_entleiher = 
//    }
    
    public Kunde getVormerker2()
    {
        return _vormerker2;
    }
    public void setVormerker2(Kunde _vormerker2)
    {
        this._vormerker2 = _vormerker2;
    }
    public Kunde getVormerker1()
    {
        return _vormerker1;
    }
    public void setVormerker1(Kunde _vormerker1)
    {
        this._vormerker1 = _vormerker1;
    }
    public Kunde getVormerker3()
    {
        return _vormerker3;
    }
    public void setVormerker3(Kunde _vormerker3)
    {
        this._vormerker3 = _vormerker3;
    }
	public Kunde getEntleiher() {
		return _entleiher;
	}
	public void setEntleiher(Kunde _entleiher) {
		this._entleiher = _entleiher;
	}

}
